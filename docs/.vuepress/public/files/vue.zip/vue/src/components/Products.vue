<script>
    export default{
        data(){
            return {
                products:[],
                isLoading: false
            }
        },
        methods:{
            async fetchProducts(){
                const res = await fetch(`http://${import.meta.env.VITE_API_HOST}/products`);
                const data = await res.json();
                this.isLoading = false;
                return data;
            }
        },
        async created(){
            this.isLoading = true;
            this.products = await this.fetchProducts();
        }
    }
</script>

<template>
    <div v-if='isLoading' class="spinner-border" role="status"></div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="product in products" :key="product.id">
                <td>{{product.id}}</td>
                <td>{{product.name}}</td>
                <td>{{product.price}}</td>
            </tr>
        </tbody>
    </table>
</template>